# The MSstats Container

Statistical test container based on the R package MSstats

## Build Commands for a directory called MSstats

$ cd MSstats
<br> $ docker build -t msstats .

## Run Commands 

$ docker run -rm -v /home/user/MSstats:/home/analysis --env VAR=Value msstats:latest

### Options for ENV variables

SRM_DATA is a .csv fils or data frame with 9 columns. More info soon.

<br>SPIKEIN_LINEAR_DATA is a .csv file or data frame with 10 columns. More info soon.

<br>SPIKEIN_NONLINEAR_DATA has the same specifications as SPIKEIN_LINEAR_DATA

## Notes on Output Files
Coming soon