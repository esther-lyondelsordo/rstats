## This is a script for testing MSstats based on the user guide in R studio
library(MSstats)

# data("SRMRawData")
# head(SRMRawData)

######

###### dataProcess
QuantData <- dataProcess(SRM)

###### dataPrcessPlots
# Profile plot
dataProcessPlots(data=QuantData, type="ProfilePlot", address = "/home/analysis/")

# Quality control plot 
dataProcessPlots(data=QuantData, type="QCPlot", address = "/home/analysis/") 

# Quantification plot for conditions
dataProcessPlots(data=QuantData, type="ConditionPlot", address = "/home/analysis/")

##### groupComparison
levels(QuantData$ProcessedData$GROUP_ORIGINAL)
comparison <- matrix(c(-1,0,0,0,0,0,1,0,0,0), nrow=1)
row.names(comparison) <- "T7-T1"

# Tests for differentially abundant proteins with models:
testResultOneComparison <- groupComparison(contrast.matrix=comparison, data=QuantData)

##### groupComparisonPlots
# based on multiple comparisons  (T1 vs T3; T1 vs T7; T1 vs T9)
comparison1<-matrix(c(-1,0,1,0,0,0,0,0,0,0),nrow=1)
comparison2<-matrix(c(-1,0,0,0,0,0,1,0,0,0),nrow=1)
comparison3<-matrix(c(-1,0,0,0,0,0,0,0,1,0),nrow=1)
comparison<-rbind(comparison1,comparison2, comparison3)
row.names(comparison)<-c("T3-T1","T7-T1","T9-T1")

testResultMultiComparisons <- groupComparison(contrast.matrix=comparison, data=QuantData)

# Volcano plot 
groupComparisonPlots(data=testResultMultiComparisons$ComparisonResult, type="VolcanoPlot", address = "/home/analysis/")

# Heatmap 
groupComparisonPlots(data=testResultMultiComparisons$ComparisonResult, type="Heatmap", address = "/home/analysis/")

# Comparison Plot
groupComparisonPlots(data=testResultMultiComparisons$ComparisonResult, type="ComparisonPlot", address = "/home/analysis/")

##### modelBasedQCPlots
testResultOneComparison <- groupComparison(contrast.matrix=comparison, data=QuantData)

# normal quantile-quantile plots
modelBasedQCPlots(data=testResultOneComparison, type="QQPlots", address = "/home/analysis/")

# residual plots
modelBasedQCPlots(data=testResultOneComparison, type="ResidualPlots", address = "/home/analysis/")

##### designSampleSize
head(QuantData$ProcessedData)

## based on multiple comparisons  (T1 vs T3; T1 vs T7; T1 vs T9)
comparison1 <- matrix(c(-1,0,1,0,0,0,0,0,0,0),nrow=1)
comparison2 <- matrix(c(-1,0,0,0,0,0,1,0,0,0),nrow=1)
comparison3 <- matrix(c(-1,0,0,0,0,0,0,0,1,0),nrow=1)
comparison <- rbind(comparison1,comparison2, comparison3)
row.names(comparison) <- c("T3-T1","T7-T1","T9-T1")

testResultMultiComparisons <- groupComparison(contrast.matrix=comparison,data=QuantData)

#(1) Minimal number of biological replicates per condition
designSampleSize(data=testResultMultiComparisons$fittedmodel, numSample=TRUE,
                 desiredFC=c(1.25,1.75), FDR=0.05, power=0.8)

#(2) Power calculation
designSampleSize(data=testResultMultiComparisons$fittedmodel, numSample=2,
                 desiredFC=c(1.25,1.75), FDR=0.05, power=TRUE)

##### designSampleSizePlots
# (1) Minimal number of biological replicates per condition
result.sample <- designSampleSize(data=testResultMultiComparisons$fittedmodel, numSample=TRUE,
                                  desiredFC=c(1.25,1.75), FDR=0.05, power=0.8)
pdf(file = "/home/analysis/Coefficient of variation.pdf")
designSampleSizePlots(data=result.sample)
dev.off()

# (2) Power
result.power <- designSampleSize(data=testResultMultiComparisons$fittedmodel, numSample=2,
                                 desiredFC=c(1.25,1.75), FDR=0.05, power=TRUE)
pdf(file = "/home/analysis/desiredFC.pdf")
designSampleSizePlots(data=result.power)
dev.off()

##### quantification
# Sample quantification
sampleQuant <- quantification(QuantData)

# Group quantification
groupQuant <- quantification(QuantData, type="Group")

##### ASSAY CHARACTERIZATION
##### nonlinearquantlim
#data("SpikeInDataNonLinear")
# Consider data from a spiked-in contained in an example dataset
head(Nonlinear)

nonlinear_quantlim_out <- nonlinear_quantlim(Nonlinear)

# Get values of LOB/LOD
nonlinear_quantlim_out$LOB[1]
nonlinear_quantlim_out$LOD[1]

##### linear_quantlim
#data("SpikeInDataLinear")
# Consider data from a spiked-in contained in an example dataset
head(Linear)

linear_quantlim_out <- linear_quantlim(Linear)

# Get values of LOB/LOD
linear_quantlim_out$LOB[1]
linear_quantlim_out$LOD[1]

##### plot_quantlim
# Consider data from a spiked-in contained in an example dataset
head(Nonlinear)

nonlinear_quantlim_out <- nonlinear_quantlim(Nonlinear, alpha = 0.05)

#Get values of LOB/LOD
nonlinear_quantlim_out$LOB[1]
nonlinear_quantlim_out$LOD[1]

plot_quantlim(spikeindata = Linear, quantlim_out  = nonlinear_quantlim_out,
              dir_output =  "/home/analysis/", alpha = 0.05)

# write json to log file?
# write_ndjson(msstats.log, logfile, echo = TRUE, overwrite = FALSE) # NO-GO??
# json_log <- toJSON('msstats.log', force = TRUE); capture.output(json_log, file = 'msstats_log', append = FALSE, type = 'output')
# ^ Still doesn't work


# put in Dockerfile:
# 'MSstatsInput.csv' is the MSstats report from Skyline.
# input <- read.csv(file="MSstatsInput.csv")
# raw <- OpenMStoMSstatsFormat(input)
