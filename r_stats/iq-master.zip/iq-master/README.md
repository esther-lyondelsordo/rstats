# The IQ Container

Statistical test container based on the R package iq

## Build Commands for a directory named iq

$ cd iq
<br> $ docker build -t iq .

## Run Commands 

$ docker run -rm -v /home/user/iq:/home/analysis --env VAR=Value iq:latest

### Options for ENV Variables
DATA is a .csv file with 9 columns. More info soon.

## Notes on Output Files
Coming soon