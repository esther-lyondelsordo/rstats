# a script for testing ANOVA, MANOVA, glht and TukeyHSD stats functions
# library(dplyr)
# library(ggpubr)
library(multcomp)
library(jsonlite)

# spikeins = read.csv("spikeins.csv") # put this line in CMD

# summarize data 
# dplyr
# spikeins$PG.ProteinGroups <- ordered(spikeins$PG.ProteinGroups, levels = levels(spikeins$PG.ProteinGroups))
# capture.output(group_by(spikeins, PG.ProteinGroups) %>% summarise(count = n(),mean = mean(F.PeakArea, na.rm = TRUE),sd = sd(F.PeakArea, na.rm = TRUE)), file = 'summary_statistics', append = FALSE, type = 'output')

# visualize 
# box plot
# ggpubr
# pdf(file = "Box Plot and Mean Plot.pdf")
# ggboxplot(spikeins, x = "PG.ProteinGroups", y = "F.PeakArea", title = "Box Plot", xlab = "Protein Groups", ylab = "Peak Area")

# mean plot
# ggline(spikeins, x = "PG.ProteinGroups", y = "F.PeakArea", add = c("mean_se", "jitter"), title = "Mean Plot with 95% CI", xlab = "Protein Groups", ylab = "Peak Area")
# dev.off()



####### START HERE IN DOCKERFILE #############
# Compute one way ANOVA
#res.aov <- aov(F.PeakArea ~ PG.ProteinGroups, data = spikeins)
###
aov.json <- toJSON(res.aov, force = TRUE)
capture.output(aov.json, file = 'AnalysisofVariance.json', append = FALSE, type = 'output')
summary.json <- toJSON(summary(res.aov), force = TRUE)
capture.output(summary.json, file = 'SummaryofAnalysisofVariance.json', append = FALSE, type = 'output')

# Interpret ANOVA
# If Pr(>F) is less than 0.05, then there are significant differences between the groups highlighted by * in the summary
# If anova is significant, can compute Tukey HSD for multiple pairwise comparisons, smallest adjusted p value is most significant
Tukey.json <- toJSON(TukeyHSD(res.aov), force = TRUE)
capture.output(Tukey.json, file = 'Tukey HSD', append = FALSE, type = 'output')
# We can also use general linear hypothesis tests
# glht <- summary(glht(res.aov, linfct = mcp(grouping = "Tukey", interaction_average=TRUE)))
# glht_json <- toJSON(glht, force = TRUE)
# capture.output(glht_json, file = 'General Linear Hypothesis Test', append = FALSE, type = 'output')
# can also use pairwise t test to calculate pairwise comparison with corrections for multiple testing
# pairwise.t.test(spikeins$F.PeakArea, spikeins$PG.ProteinGroups, p.adjust.method = 'BH')

# Test the validity of your ANOVA, test hommogeneity of variances
# residuals vs Fit plot:
pdf(file = "HomogeneityofVariancesandNormalityPlots.pdf")
plot(res.aov, 1)
# can use levene's test in lawstat or car
 #If homogeneity f variances is violated, we can save the ANOVA with oneway.test or pairwise t test
# oneway.test(F.PeakArea ~ PG.ProteinGroups, data = spikeins)

#check the normality assumption 
# normality plot to check that residuals are normally distributed, points should fall approximately on reference line
plot(res.aov, 2)
dev.off()
# if the data are normal, can use shapiro-wilk test, sample size ust be between 3 and 5000
aov_residuals <- residuals(object = res.aov )
shapiro <- shapiro.test(x = aov_residuals[0:5000])
shapiro_json <- toJSON(shapiro, force = TRUE)
capture.output(shapiro_json, file = 'shapirotest.json', append = FALSE, type = 'output')

# non parametric alternative to aov is kruskal.test
# kruskal.test(F.PeakArea ~ PG.ProteinGroups, data = spikeins)
