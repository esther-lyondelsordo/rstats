# The Analysis of Variance (ANOVA) Container

A container with a workflow for ANOVA functions in R

## Build Commands for a directory named anova

$ cd anova
<br> $ docker build -t anova .

## Run Commands 

$ docker run -rm -v /home/user/anova:/home/analysis --env VAR=Value anova:latest

### Options for ENV Variables
DATA is .csv file or data frame containing the columns of interest for the analysis

<br>FUNC is where you specify between the normal and multivariate ANOVA functions
- for one and two way analysis of variance: FUNC=aov
- for multivariate analysis of variance; FUNC=manova

<br>GROUPING
- for one way, two way, and multivariate: GROUPING=name_of_grouping_column 
- note: this column must contain grouping data

<br>GROUPING_2
- for two way only: GROUPING_2=+name_of_second_grouping_column,interaction_average=TRUE
- must have plus sign!!!!

<br>VALUES
- for one way and two way: VALUES=name_of_value_column
- for multivariate: VALUES=cbind(name_of_value_col_1,name_of_value_col_2)
- note: these columns must contain numeric values that are grouped by the grouping column(s)
- note: manova/multivariate will only produce output for analysis of variance and aov summary

## Notes on Output Files
Coming soon