# The Base R Statistics Container

Statistical test container for functions from the base R statistics package

## Build Commands for a directory named stats

$ cd stats
<br> $ docker build -t stats .

## Run Commands 

$ docker run -rm -v /home/user/stats:/home/analysis --env VAR=Value stats:latest

### Options for ENV Variables

FUNC this is the name of the statistical function you would like to run on your data. Possible functions are below.
- FUNC=t.test
- FUNC=pairwise.t.test
- FUNC=ks.test
- FUNC=kruskal.test
- FUNC=wilcox.test
- FUNC=chisq.test
- FUNC=fisher.test
- FUNC=dixon.test
- FUNC=levene.test
- FUNC=oneway.test

<br>DATA a .csv file or data frame with columns that can be subsetted
<br>
<br>COL1 a column from the data frame that can be passed into the desired test
- for all functions: COL1=col_1_name

<br>COL2 some tests require a second column
- for oneway.test: COL2=~col_2_name
- for dixon.test: no COL2
- for all others: COL2=,data_frame_name\$col_2_name


<br>FILE_NAME can be specified to be specific to the test being applied. Will default to test_results.json

<br>OPTIONAL some test functions require an additional argument
- for oneway.test: OPTIONAL=,data=data_frame_name
- for fisher.test: OPTIONAL=,simulate.p.value=TRUE

## Notes on Output Files
Coming soon